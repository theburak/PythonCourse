# ML_Course_19-11-20
Global AI Hub Intro to ML Course Nigeria
